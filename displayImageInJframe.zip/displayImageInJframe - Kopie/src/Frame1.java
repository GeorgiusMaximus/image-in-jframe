import javax.swing.*;
import java.io.File;
import java.util.Random;

public class Frame1 {

    public  void frame(){
        JFrame frame = new JFrame("Bild anzeigen");
        ImageIcon bildIcon = new ImageIcon(new File("src/images/goofy.png").getAbsolutePath());
        Random framePositionX = new Random();
        Random framePositionY = new Random();
        framePositionX.nextInt(0,500);
        framePositionY.nextInt(0,500);
        JLabel label = new JLabel(bildIcon);
        frame.add(label);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //frame.setLocationRelativeTo(null);
        frame.setLocation(framePositionX.nextInt(0,500), framePositionY.nextInt(0,500));
        frame.pack();
        frame.setVisible(true);


    }






}

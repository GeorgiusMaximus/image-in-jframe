
public class Main {
    public static void main(String[] args) {

        try {
            // Pause für 3 Sekunden (3000 Millisekunden)

            while (0<10){
                Thread.sleep(30);
                new Frame1().frame();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
